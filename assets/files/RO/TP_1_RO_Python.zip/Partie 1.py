def combinaisons(tab, k):
    if k == len(tab):
        print(tab)
    else:
        tab[k] = 0
        combinaisons(tab, k + 1)
        tab[k] = 1
        combinaisons(tab, k + 1)


if __name__ == "__main__":
    n = 3
    tab = [-1] * n
    combinaisons(tab, 0)