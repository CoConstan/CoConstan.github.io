sacs_a_dos = []

def combinaisons(tab, k):
    if k == len(tab):
        sacs_a_dos.append(tab.copy())
    else:
        tab[k] = 0
        combinaisons(tab.copy(), k + 1)
        tab[k] = 1
        combinaisons(tab.copy(), k + 1)

def sac_a_dos_bruteforce(poids, valeurs, poids_maximal):
    valeur_du_meilleur_sac = 0
    for sac_a_dos in sacs_a_dos:
        poids_courant = 0
        valeur_courante = 0
        for i in range(len(sac_a_dos)):
            poids_courant += sac_a_dos[i] * poids[i]
            valeur_courante += sac_a_dos[i] * valeurs[i]
        
        if poids_courant <= poids_maximal and valeur_courante > valeur_du_meilleur_sac:
            meilleur_sac = sac_a_dos
            valeur_du_meilleur_sac = valeur_courante
            poids_du_meilleur_sac = poids_courant
    
    print(f"Le sac à dos choisi par l'algorithme brute-force est {meilleur_sac} avec un poids de {poids_du_meilleur_sac}/{poids_maximal} et une valeur de {valeur_du_meilleur_sac}") # type: ignore

def tri_des_objets(poids, valeurs):
    for i in range(len(valeurs)):
        indice_meilleur_ratio = i
        for j in range(i + 1, len(valeurs)):
            ratio_j = valeurs[j] / poids[j]
            ratio_meilleur = valeurs[indice_meilleur_ratio] / poids[indice_meilleur_ratio]
            if ratio_j > ratio_meilleur:
                indice_meilleur_ratio = j

        valeurs[i], valeurs[indice_meilleur_ratio] = valeurs[indice_meilleur_ratio], valeurs[i]
        poids[i], poids[indice_meilleur_ratio] = poids[indice_meilleur_ratio], poids[i]

        # tmp = valeurs[i]
        # valeurs[i] = valeurs[indice_de_ratio_max]
        # valeurs[indice_de_ratio_max] = tmp
        # tmp = poids[i]
        # poids[i] = poids[indice_de_ratio_max]
        # poids[indice_de_ratio_max] = tmp

    return poids, valeurs

def sac_a_dos_glouton(poids, valeurs, poids_maximal):    
    poids_tries, valeurs_tries = tri_des_objets(poids, valeurs)

    poids_total = 0
    valeur_totale = 0
    sac_glouton = []

    for i in range(len(poids_tries)):
        if poids_total + poids_tries[i] <= poids_maximal:
            poids_total += poids_tries[i]
            valeur_totale += valeurs_tries[i]
            sac_glouton.append(1)
        else:
            sac_glouton.append(0)

    print(f"Le sac à dos choisi par l'algorithme glouton est {sac_glouton} avec un poids de {poids_total}/{poids_maximal} et une valeur de {valeur_totale}") # type: ignore
    
if __name__ == "__main__":
    poids = [2, 3, 4, 3, 2, 7]
    valeurs = [4, 5, 2, 1, 4, 14]
    poids_maximal = 10

    tab = [-1] * len(poids)
    combinaisons(tab, 0)

    # print(sacs_a_dos)
    # print(f"Nombre de sacs à dos possibles : {len(sacs_a_dos)}")

    sac_a_dos_bruteforce(poids, valeurs, poids_maximal)

    sac_a_dos_glouton(poids, valeurs, poids_maximal)